import os
os.system("shutdown /s /t 300")
print("You have been OWNED")
print("System Shutdown initiated!")