# bad_python_extract
A vulnerable web application written in Python Flask to demonstrate insecure file extraction

### Usage

```
pip install -r requirements.txt --user
python server.py
```

This will start the server at `http://0.0.0.0:3000`
