HOST = "0.0.0.0"
PORT = 3000
DEBUG = True
ALLOWED_EXTS = ["zip", "apk"]
